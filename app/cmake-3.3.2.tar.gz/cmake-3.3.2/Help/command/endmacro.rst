endmacro
--------

Ends a list of commands in a macro block.

::

  endmacro(expression)

See the macro command.
