.. cmake-module:: ../../Modules/FindQt4.cmake
